# 4. blokea. Hedapen segurua

Aplikazio web bat ez da segurua bihurtzen garapena amaitzen denean.

Produkziora pasatzeak segurtasunari zuzenean eragin diezaiokeen erabaki berriak sorrarazten ditu:

- ingurunearen konfigurazioa;
- sekretuen kudeaketa;
- zerbitzuen esposizioa;
- ziurtagiriak eta komunikazioak;
- sistemaren baimenak;
- datu-baseetara sartzea;
- jardueren erregistroa;
- zerbitzariaren konfigurazioa.

Programazioan ondo programatutako aplikazio bat arriskuan egon daiteke exekutatzen den ingurunea behar bezala konfiguratu ez badago.

## Segurtasuna bizitzako ziklo osoan

Segurtasuna ez da inplementazioan amaitzen.

Hedapena aplikazio baten bizitzako zikloaren parte da:

```text
Analisiak
   ↓
Diseinu segurua
   ↓
Inplementazio segurua
   ↓
Probak
   ↓
Hedapen segurua
   ↓
Mantentze-lana
```

Fase bakoitzak arriskua gutxitzen edo handitzen duen erabakiak sorrarazten ditu.

## Garapena eta produkzioa

Garapenean normalean aplikazioa sortu eta probatzeko errazten duten konfigurazioak erabiltzen dira:

- erroreen mezu xeheak;
- arazketa-erreminta;
- probako datuak;
- tokiko zerbitzuak;
- aldi baterako konfigurazioak.

Aukera hauek ez dira zuzenean produkzio-ingurura eraman behar.

Inguru errealak lehentasuna eman behar dio:

- eskuragarritasunari;
- konfidentzialtasunari;
- osotasunari;
- sarbide-kontrolari;
- trazabilitateari.

## Garatzaile webaren papera

Hedapen segurua ez da soilik sistema-administratoreren ardura.

Garatzaileak jakin behar du bere erabakiek ingurunean nola eragiten duten:

- non gordetzen diren sekretuak;
- zein zerbitzu behar dituen aplikazioak;
- zein baimen behar dituen;
- zein informazio erakusten zaion erabiltzaileari;
- nola erregistratzen diren erroreak;
- nola komunikatzen den aplikazioa beste zerbitzu batzuekin.

Helburua ez da azpiegitura osoa administratzea, baizik modu seguruan zabaltzeko gai diren aplikazioak garatzea.

## DAW erronken erlazioa

Ikastaroan garatutako proiektuak ingurune erreal batean aplikatu behar dute erabaki hauek.

Adibidez:

```text
Garatutako aplikazioa
        ↓
Produkzio-konfigurazioa
        ↓
Web zerbitzaria
        ↓
Datu-basea
        ↓
Erabiltzaile finalak
```

Hedapenean berrikusi egingo da:

- aplikazioak HTTPS erabiltzen duela;
- sekretuak ez daudela kodean barne;
- datu-basea ez dagoela beharrezkoa ez den moduan erakutsita;
- baimenak egokiak direla;
- erroreek ez dutela barne-informazioa ezagutarazten;
- zerbitzariak beharrezkoa dena baino ez duela erakusten.

## SINF-en erlazioa

Hedapen segurua garapenaren eta azpiegituraren arteko lankidetza eskatzen du.

Modulu honetan garapen web-aren ikuspegitik lan egingo da:

- zer behar duen aplikazioak;
- zer konfigurazio espero duen;
- zein arrisku agertzen diren gaizki zabaltzen bada.

Sistema eragilearen, sareen edo zerbitzuen administrazio aurreratuaren alderdiak beste moduluetan lantzen dira.

## Bloke honen ikuspegia

Bloke honetan landuko dira:

- inguruneen arteko konfigurazio desberdina;
- HTTPS eta ziurtagiriak;
- sekretuen kudeaketa segurua;
- zerbitzariaren esposizio-azalera;
- fitxategien baimenak;
- datu-basearen babesa;
- segurtasun-buruzagiak;
- erroreen eta erregistroen kudeaketa.

Helburua da ulertzea aplikazio segurua ingurune segurua ere behar duela.

## Giltzarri ideia

> Aplikazio segurua ez da soilik bere kodearen araberakoa. Konfiguratzen, argitaratzen eta mantentzen den moduan ere erabakitzen da.
