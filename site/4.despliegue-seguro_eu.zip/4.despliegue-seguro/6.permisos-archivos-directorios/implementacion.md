# Fitxategien eta direktorioen baimenak ezartzea

Baimen-konfigurazioa hedapen-prozesuaren parte gisa egin behar da.

Helburua aplikazioak behar duen baimenak zehazki izatea da, baina ez gehiago.

## Permisosak esleitzea baino lehen egitura berrikustea

Baimenak aldatzeko baino lehen honakoak identifikatu behar dira:

- aplikazioaren kodea;
- konfigurazio-fitxategiak;
- sortutako datuen karpetak;
- erabiltzaileek igotako fitxategiak;
- erregistroak.

Adibidea:

```text
/var/www/txurdigest

├── app/
├── config/
├── public/
├── storage/
└── vendor/
```

Eremu bakoitzak beharrizan ezberdinak ditu.

## Fitxategien jabea

Ohiko praktika bat da kodea hedapen-erabiltzaile baten jabetza izatea eta web-zerbitzariak irakurketa-sarbidea izatea.

Adibide kontzeptuala:

```text
Kodea

jabea:
hedapen-erabiltzailea

web-zerbitzariaren sarbidea:
irakurketa
```

Web zerbitzariak ez du fitxategi guztiak aldatu behar.

## Jabea eta taldea esleitzea

Linux-ek jabea eta taldea aldatzeko aukera ematen du:

```bash
chown
```

Adibidea:

```bash
sudo chown -R erabiltzailea:taldea /var/www/txurdigest
```

Aukera zehatza zerbitzariaren arkitekturaren araberakoa da.

Garrantzitsuena da jabearen aukeraketa aplikazioaren funtzionamenduarekin koherentea izatea.

## Irakurketa eta idazketa baimenak

Baimenak funtzio-beharrei erantzun behar diete.

Adibidea:

```text
PHP kodea

irakurketa


Logs

irakurketa/idazketa


Uploads

irakurketa/idazketa
```

Ez da aplikazio osoari idazketa globala aplikatu behar.

## Baimen gehiegi saihestea

Praktika okerra:

```bash
chmod -R 777 /var/www/txurdigest
```

Nahiz eta baimen-arazoak azkar konpontzen lagun, arrisku hau sortzen du:

- edozein erabiltzailek fitxategiak aldatu ditzake;
- konprometitutako prozesu batek aplikazioa alda dezake;
- ahultasun baten eragina handitzen da.

Baimen minimoa beharrezkoa da.

## Baimen-adibidea

Balizko konfigurazioa:

```text
Aplikazio-fitxategiak:

644


Direktorioak:

755
```

Idazketa behar duten karpetak:

```text
storage/

775
```

Balio hauek ohikoak dira, baina zerbitzari errealera moldatu behar dira.

## Laravel-en baimenak

Laravel-ek idazketa behar duen zenbait karpeta erabiltzen ditu.

Normalean:

```text
storage/

bootstrap/cache/
```

Adibidea:

```bash
chmod -R 775 storage bootstrap/cache
```

Web-prozesuak horietan idazteko aukera izan behar du.

Proiektuaren gainerakoak ez du idazketa-baimenik behar.

## Erabiltzaileek igotako fitxategiak

Igoera-karpetek arreta berezia behar dute.

Adibidea:

```text
storage/uploads/
```

Baimendu behar du:

```text
fitxategiak gorde

baimendutako erabiltzaileek irakurri
```

baina ez du baimendu behar:

```text
kodea exekutatu
```

Babesa honela konbinatu behar da:

- baimenak;
- kokapen zuzena;
- zerbitzariaren konfigurazioa;
- aplikazioaren balidazioa.

## Fitxategi sentikorrak babestea

Honako fitxategiak:

```text
.env

giltza pribatuak

logs

barne-konfigurazioa
```

baimen mugatuekin eduki behar dira.

Adibide kontzeptuala:

```text
Aplikazioa

irakurri dezake


Kanpoko erabiltzaileak

sarbiderik ez
```

Gainera, ez dira inoiz web-zerbitzariaren bidez argitaratu behar.

## Baimenak berrikustea

Baimenak berrikusteko:

```bash
