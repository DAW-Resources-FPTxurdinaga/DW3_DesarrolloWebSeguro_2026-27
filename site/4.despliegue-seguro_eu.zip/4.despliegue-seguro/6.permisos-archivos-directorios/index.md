# Fitxategien eta direktorioen baimenak

Fitxategi-sistemaren baimenek aplikazioaren fitxategiak irakurri, aldatu edo exekutatu ahal izango dituen zehazten dute.

Konfigurazio oker batek nahi ez diren aldaketak baimendu edo informazio sentikorra agerian utzi dezake.

Hedapen segurua egiteko helburua gutxieneko pribilegioaren printzipioa aplikatzea da:

> Elementu bakoitzak funtzionatzeko behar dituen baimenak soilik izan behar ditu.

## Erabiltzaileak eta prozesuak

Zerbitzari Linux batean aplikazioa ez da zuzenean pertsona baten moduan exekutatzen.

Normalean web-zerbitzariari lotutako prozesu bat dago:

```text
Kanpoko erabiltzailea

        ↓

Web zerbitzaria

        ↓

Aplikazioaren prozesua
```

Prozesu horrek sistema-erabiltzaile batekin lan egiten du, baimen zehatzekin.

Segurtasuna erabiltzaile horrek zer egin dezakeen araberakoa da.

## Jabea, taldea eta baimenak

Linux-ek baimenak honela esleitzen ditu:

```text
Jabea

Taldea

Beste erabiltzaileak
```

Denek honako baimenak izan ditzakete:

```text
r  irakurketa

w  idazketa

x  exekuzioa
```

Adibidea:

```text
-rw-r----- 
```

Kontzeptu mailan honela esan nahi du:

```text
Jabea:
irakurketa + idazketa

Taldea:
irakurketa

Besteak:
sarbiderik ez
```

## Baimen gehiegiaren arriskua

Ohikoa baina ez-segurua den praktika bat hau da:

```bash
chmod -R 777 aplikazioa/
```

Honek honakoak baimentzen ditu:

```text
denek irakurri ahal dute

denek idatzi ahal dute

denek exekutatu ahal dute
```

Arazoa da sarbidea duen edozein erabiltzaile edo prozesuk aplikazioaren fitxategiak aldatu ahal izatea.

Baimenak espezifikoak izan behar dira.

## Kodea eta idazketa-karpetak

Ez dira fitxategi guztiak berdin behar.

Aplikazio batek normalean honakoak izan ditzake:

```text
Iturburu kodea

        ↓

irakurketa soilik


Almacenamendu temporala

        ↓

irakurketa/idazketa
```

Adibidea:

```text
app/

irakurketa soilik


storage/

idazketa beharrezkoa
```

Proiektu osoari idazketa emateak arriskua handitzen du.

## Idazketa behar duten karpetak

Zenbait aplikazioek fitxategiak aldatzeko gai izan behar dira:

- logs;
- cache-ak;
- igotako fitxategiak;
- saioak gordetzea.

Karpeta hauek identifikatu behar dira.

Adibide Laravel:

```text
storage/

bootstrap/cache/
```

web-prozesuak idazteko aukera izan behar du.

Aplikazioaren gainerakoak ez du idazketa-baimen beharrezkoak izan behar.

## Fitxategi sentikorrak

Zenbait fitxategik babesa gehigarria behar dute:

```text
.env

konfigurazioa

giltza pribatuak

babeskopiak

logs
```

Ez dira kanpoko erabiltzaileek edo behar ez dituzten prozesuek atzitu behar.

## Aplikazioaren eta sortutako datuen arteko bereizketa

Praktika ona hau da:

```text
Aplikazioa

        ↓

Kode babestua


Sortutako datuak

        ↓

Kokapen kontrolatua
```

Adibidea:

```text
/var/www/txurdigest/

    app/

    public/

    storage/
```

Kodea egonkor mantentzen da.

Sortutako datuak kokapen espezifikoetan gordetzen dira.

## Erabiltzaileek igotako fitxategiak

Erabiltzaileek igotako fitxategiak gordetzen dituzten karpetek arreta berezia behar dute.

Behar dute:

- idazketa ahalbidetu behar denean;
- exekuzioa eragotzi;
- norbaitek atzitu dezakeen kontrolatu.

Adibidea:
