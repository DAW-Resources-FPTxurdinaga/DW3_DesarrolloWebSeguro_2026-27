# Zerbitzaria eta esposizio-azalera

Aplikazio bat Interneten argitaratzen denean ez da gehiago garapen-taldearen kontrolpean bakarrik egoten.

Zerbitzaria, aktibatutako zerbitzuak, irekitako atariak eta sare-konfigurazioa zehazten dute aplikazioaren zein zati dauden kanpoko erabiltzaileentzat eskuragarri.

Hedapen segurua egiteko helburua esposizio-azalera murriztea da:

> Aplikazioak behar duenari baino ez dagokio izan eskuragarri.

## Zer da esposizio-azalera

Espozizio-azalerak kanpoko interakzioak jaso ditzaketen elementu guztiak adierazten ditu.

Honakoak izan ditzake:

- web-orriak;
- APIak;
- irekitako atariak;
- sistemaren zerbitzuak;
- datu-baseak;
- kudeaketa-panelak;
- eskuragarri dauden fitxategiak;
- zerbitzu laguntzaileak.

Zenbat eta elementu gehiago izan eskuragarri, orduan eta aukera gehiago daude erroreak edo konfigurazio okerrak izateko.

Kontzeptu mailan:

```text
Zerbitzu gehiago esposatuta

        ↓

Espozizio-azalera handiagoa

        ↓

Babesak beharrezkoak izatea
```

## Aplikazio web baten oinarrizko arkitektura

Ohiko arkitektura hau:

```text
Erabiltzailea

   ↓ HTTPS

Web zerbitzaria

   ↓

Aplikazioa

   ↓

Datu-basea
```

Osagai bakoitzak erantzukizun ezberdina du.

Erabiltzaileak ez luke barneko elementu guztiak zuzenean atzitu behar.

## Zerbitzuen esposizio zuzena

Konfigurazio segurua sarbideak mugatzen saiatzen da:

```text
Internet

    ↓

HTTPS ataria

    ↓

Web zerbitzaria

    ↓

Aplikazioa

    ↓

Datu-base pribatua
```

Datu-basea ez luke Interneten zuzenean argitaratu behar.

Modelo ez-zuzena:

```text
Internet

    ↓

Datu-basea
```

Aplikazioak intermediario gisa jokatu behar du.

## Atariak eta zerbitzuak

Zerbitzu bakoitzak normalean komunikazio-atariko bat erabiltzen du.

Adibideak:

```text
HTTP
80

HTTPS
443

SSH
22

MySQL
3306
```

Ez du esan nahi guztiak Internetetik eskura daudenik.

Oinarrizko araua:

```text
Zerbitzu beharrezkoa

        ↓

Sarbidea baimendu


Zerbitzu beharrezkoa ez dena

        ↓

Ez erakutsi
```

## Gutxieneko sarbidearen printzipioa

Zerbitzariaren konfigurazioak gutxieneko pribilegioaren printzipioa ezarri behar du.

Adibideak:

Web zerbitzari batek honakoa behar du:

```text
HTTPS eskaerak onartzea
```

baina ez du zertan behar:

```text
Datu-basearen konexio zuzenak Internetetik onartzea
```

Konfigurazioak mugatu behar du norbaitek zerbitzu bakoitzarekin komunikatu ahal duen.

## AWS-rekin erlazioa

AWS-n kontrol hau honelako elementuekin aplikatu daiteke:

- Security Groups;
- azpiegiturak;
- zerbitzu publiko eta pribatuen arteko bereizketa.

Ohiko arkitektura:

```text
Internet

    ↓

Zerbitzu web publikoa

    ↓

Barne-sarea

    ↓

Datu-base pribatua
```

Datu-baseak aplikazioarekin komunikatu ahal du, baina ez da zuzenean Internetetik atzi daiteke.

## Security Groups

Security Group sareko sarbide-kontrol gisa funtzionatzen du.

Honakoak definitzeko aukera ematen du:

- zein atari ireki dauden;
- zein jatorritatik;
- zein baliabideri.

Adibidea:

Web zerbitzaria:

```text
Baimendu:

443 HTTPS
```

Datu-basea:

```text
Baimendu:

3306

soilik web zerbitzaritik
```
