# Zerbitzaria eta esposizio-azalera ezartzea

Zerbitzariaren segurtasuna diseinu garaian definitutako arkitektura behar bezala aplikatuz definitzen da.

Helburua ez da osagai guztiak eskuragarri izatea, baizik beharrezko komunikazioak soilik baimentzea.

## Aplikazio web baten gomendatutako egitura

Aplikazio batek ez luke bere fitxategi guztiak direktorio publikoan kokatu behar.

Adibidea:

```text
Aplikazioa

├── app/
├── config/
├── storage/
├── vendor/
└── public/
    ├── index.php
    ├── css/
    └── js/
```

Web zerbitzariak soilik honetara apuntatu beharko luke:

```text
public/
```

Gainontzeko karpetak nabigatzailearen bidez sarbide zuzenetik kanpo egon beharko lukete.

## Osorik aplikazioa argitaratzeko arriskua

Konfigurazio oker batek:

```text
Web zerbitzaria

    ↓

/var/www/txurdigest/
```

barneko fitxategi eskuragarri egin ditzake:

```text
.env

config/

logs/

vendor/

babeskopia-fitxategiak
```

Konfigurazio egokitu bat:

```text
Web zerbitzaria

    ↓

/var/www/txurdigest/public/
```

esposizioa mugatzen du.

## Web zerbitzariaren konfigurazioa

Zerbitzariak jakin behar du:

- domeinua;
- erroko direktorio publikoa;
- HTTPS ziurtagiriak;
- beharrezko baimenak;
- sarbide-arauak.

Kontzeptu mailan:

```text
HTTP eskaera

        ↓

Web zerbitzaria

        ↓

Direktorio publikoa

        ↓

Aplikazioa
```

Zerbitzariak ez luke barneko fitxategietara zuzenean sartzeko aukera eman behar.

## Fitxategi sentikorrak

Zenbait fitxategi kanpoan egon behar dute nabigatzailearen esparruetatik:

```text
.env

.git/

barne-konfigurazioa

logs

babeskopiak

aldi baterako fitxategiak
```

Erraza da URL baten bidez sartzen saiatu:

```text
https://domeinua/.env
```

Erantzun egokiak ez luke edukia erakutsi behar.

## Apache-ren konfigurazioa

Apache-n aplikazio bat Virtual Host bidez konfigura daiteke.

Adibide kontzeptuala:

```apache
<VirtualHost *:443>

    ServerName txurdigest.adibidea

    DocumentRoot /var/www/txurdigest/public

</VirtualHost>
```

Erabaki garrantzitsua hau da:

```text
DocumentRoot

        ↓

public/
```

eta ez proiektuaren karpeta osoa.

## Nginx-en konfigurazioa

Kontzeptua baliokidea da:

```nginx
server {

    server_name txurdigest.adibidea;

    root /var/www/txurdigest/public;

}
```

Zerbitzariak soilik definitutako sarrera-puntua argitaratzen du.

## Oinarrizko baimenak

Baimenak honako printzipioa jarraitu behar dute:

```text
gutxieneko baimenak beharrezkoak
```

Aplikazioak honakoak egin behar ditu:

- beharrezko fitxategiak irakurri;
- idatzi soilik beharrezkoa den tokian.

Adibidea:

```text
Iturburu kodea

irakurketa

↓

Web zerbitzaria


Karpetak uploads

irakurketa/idazketa

↓

Web zerbitzaria
```

Ez litzateke:

```bash
chmod 777
```

erabili behar soluzio orokor gisa.

Baimen gehiegiak posible den arazo baten eragina handitzen du.

## Idazketa behar duen karpetak

Zenbait aplikazioek datuak idatzi behar dituzte:

