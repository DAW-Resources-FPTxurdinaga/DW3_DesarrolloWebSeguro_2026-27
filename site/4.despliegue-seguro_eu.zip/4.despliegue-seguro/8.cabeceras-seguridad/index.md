# Segurtasun-buruzagiak HTTP

HTTP goiburuak zerbitzariak nabigatzaileari erantzun bati buruz informazio osagarria eskaintzeko aukera ematen du.

Datuak garraiatu ez ezik, HTTP-k segurtasun-politika jakin batzuk ezartzeko aukera ere ematen du, aplikazio web baten exekuzioan zenbait arrisku murrizteko.

Goiburu hauek hedapenaren konfigurazioaren parte dira.

## Zerbitzaria politikak sortzeko jatorria

Aplikazio web batek ez du soilik edukiera segurua sortu behar.

Era berean nabigatzaileari zein portaera baimenduta dagoen adierazi behar dio.

Kontzeptu mailan:

```text
Zerbitzaria

    ↓

HTTP erantzuna

    ↓

Segurtasun-buruzagiak

    ↓

Nabigatzaileak politikak aplikatzen ditu
```

Zerbitzariak bezeroari murrizketak komunikatzen dizkio.

## Segurtasuna eta garapena

Segurtasun-buruzagiak aurretik landutako bestelako neurriekin osatzen dute:

```text
Sarrerak balidatzea

        +

Irteera segurua

        +

Autentikazioa

        +

Zerbitzariaren konfigurazioa

        +

HTTP goiburuak
```

Ez dute kode segurua ordezten.

Babes-geruza osagarri bat dira.

## Content-Security-Policy (CSP)

Goiburu hau:

```http
Content-Security-Policy
```

baimendu nahi diren baliabideak zein jatorritatik kargatu daitezkeen definitzeko aukera ematen du.

Honakoak kontrola ditzake:

- script-ak;
- estiloak;
- irudiak;
- letra-tipoak;
- kanpoko konexioak.

Adibide kontzeptuala:

```http
Content-Security-Policy:
default-src 'self'
```

Adierazten du, lehenetsitako moduan, baliabideak jatorri beretik etorri behar direla.

## XSS-ekin erlazioa

CSP-k zenbait XSS erasoen eragina murrizten lagun dezake.

Adibidez, politika mugatzaile batek zaildu dezake nabigatzaileak baimendu gabeko script-ak exekutzea.

Hala ere:

```text
CSP

ez du ordezten

irteera ihes egitea + balidazioa
```

Aplikazioak edukiera segurua sortzen jarraitu behar du.

## X-Content-Type-Options

Goiburu hau:

```http
X-Content-Type-Options
```

baimentzen du nabigatzaileak baliabidea deklaratutako motarekin ezberdina den moduan interpretatzea saihestea.

Adibidea:

```http
X-Content-Type-Options: nosniff
```

Edukiak interpretatzeko portaera ezusteko batzuk murrizten ditu.

## Strict-Transport-Security (HSTS)

Goiburu hau:

```http
Strict-Transport-Security
```

nabigatzaileari adierazten dio denbora jakin batean HTTPS erabili behar duela.

Adibidea:

```http
Strict-Transport-Security:
max-age=31536000
```

Honek HTTP bidezko sarbideak saihesten laguntzen du.

HTTPS behar bezala konfiguratu denean soilik erabili behar da.

## Referrer-Policy

Nabigatzaileak orri batetik bestera egiteko eskaera bat egiten duenean, jatorrizko orriari buruzko informazioa bidali dezake.

Goiburu hau:

```http
Referrer-Policy
```

baimendzen du zein informazio partekatu den kontrolatzea.

Adibidea:

```http
Referrer-Policy: strict-origin
```

Beste guneei bidaltzen den informazioa murrizten du.

## Permissions-Policy

Goiburu hau:

```http
Permissions-Policy
```

nabigatzailearen gaitasun jakin batzuk kontrolatzeko aukera ematen du.

Adibideak:

- kamera;
- mikrofonoa;
- geokokapena.

Ez du erabiltzen gaitasuna duen aplikazio batek murriztu dezake.

## Zerbitzaritik konfigurazioa

Goiburu hauek normalean honela konfiguratu dira:

- Apache;
- Nginx;
- aplikazio-zerbitzariak;
- hedapen-plataformak.

Apache-n adibide kontzeptuala:

```apache
Header always set X-Content-Type-Options "nosniff"
```

Zehazki non kokatu behar den zerbitzariaren arabera aldatzen da.

## Ez gehitu goiburuak ulertu gabe

Praktika txarra zerrenda bat kopiatzea da, bere efektua ez ezagututa.

Politika bakoitzak beharrizan bati erantzun behar dio:

```text
Zer babesten du?

Zer hondatu dezake?

Aplikazioak funtzionaltasun hori behar du?
```

Konfigurazio gehiegi mugatzaile batek aplikazioa behar bezala funtzionatzea eragotzi dezake.

## Nabigatzailean egiaztatzea
