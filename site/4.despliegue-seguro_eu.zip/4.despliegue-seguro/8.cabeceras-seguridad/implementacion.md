# Segurtasun-buruzagiak HTTP ezartzea

Segurtasun-buruzagiak normalean aplikazioa entregatzen duen zerbitzarian konfiguratu ohi dira.

Helburua da HTTP erantzun bakoitzak nabigatzaileari politika egokiak barne hartzea da.

Fluxua:

```text
Erabiltzailea

    ↓

Web zerbitzaria

    ↓

HTTP erantzuna

    ↓

Segurtasun-buruzagiak

    ↓

Nabigatzaileak murrizketak aplikatzen ditu
```

## Apache-n konfigurazioa

Apache-k konfigurazio-moduluen bidez goiburuak gehitzeko aukera ematen du.

Adibidea:

```apache
Header always set X-Content-Type-Options "nosniff"
```

Zerbitzariaren erantzunak honako hau barne hartuko du:

```http
X-Content-Type-Options: nosniff
```

Nabigatzaileak politika hori aplikatuko du.

## Nginx-en konfigurazioa

Nginx-en goiburuak honela gehi daitezke:

```nginx
add_header X-Content-Type-Options "nosniff";
```

Ideia bera da:

```text
Zerbitzaria

        ↓

Goiburua gehitu

        ↓

Bezeroak politika jasotzen du
```

## Content-Security-Policy

CSP da garrantzitsuenetako bat, nabigatzaileak zer baliabide exekutatu edo kargatu ditzakeen kontrolatzeko.

Hasierako adibidea:

```http
Content-Security-Policy:
default-src 'self'
```

Esanahia:

```text
Lehenetsita

↓

Jatorri beretik soilik baliabideak
```

## CSP eta aplikazioaren eboluzioa

CSP politika aplikazio errealera moldatu behar da.

Aplikazio batek honakoak behar ditzake:

- script propioak;
- estilo-orriak;
- irudiak;
- letra-tipoak;
- API kanpokoak.

Horregatik, ez da behar bezain mugatzaile politika aplikatu funtzionamendua egiaztatu gabe.

Adibidea:

```text
Aplikazioa

        ↓

Erabilitako baliabideak berrikusi

        ↓

Politika egokia definitu
```

## CSP ez-seguruen konfigurazioak saihestea

Hona bezalako konfigurazioak:

```http
script-src 'unsafe-inline'
```

zenbait arazoen aurkako babesa murriztu dezake.

Beharrezko kasuetan eta bere ondorioak ulertuta soilik erabili behar da.

## HSTS

Goiburu hau:

```http
Strict-Transport-Security
```

nabigatzaileari HTTPS erabiltzea adierazten dio.

Adibidea:

```http
Strict-Transport-Security:
max-age=31536000
```

Aktibatu aurretik egiaztatu behar da:

- HTTPS ondo funtzionatzen duela;
- baliabide guztiak HTTPS bidez eskuragarri daudela;
- aplikazioaren zati batzuk HTTP-ren menpe ez daudela.

## X-Content-Type-Options

Ohiko konfigurazioa:

```http
X-Content-Type-Options: nosniff
```

Eragozten du nabigatzaileak baliabidea deklaratutako motarekin ezberdina den moduan interpretatzea.

Bereziki erabilgarria da aplikazioak zerbitzatzen dituenean:

- fitxategiak;
- irudiak;
- dokumentuak;
- deskargatzeko baliabideak.

## Referrer-Policy

Adibidea:

```http
Referrer-Policy: strict-origin
```

Erabiltzaileak beste guneetara nabigatzen duenean bidaltzen den informazioa kontrolatzeko aukera ematen du.

Politika aukeratuak honako bi alderdiak orekatzea behar du:

```text
Pribatutasuna

        +

Funtzionalitate-beharreiak
```

## Permissions-Policy

Aplikazio batek ez erabiltzen dituen nabigatzailearen gaitasunak mugatu ditzake.

Adibide kontzeptuala:

```http
Permissions-Policy:
camera=(), microphone=()
```

Adierazten du aplikazioak ez duela kamera edo mikrofonoaren sarbiderik behar.

## DevTools-ekin goiburuak egiaztatzea
