# Sekretuak eta ingurune-aldagaiak ezartzea

Sekretuen kudeaketa hedapenean aplikazioari beharrezko konfigurazioa ematea da, kode iturburuan informazio sentikorik barne ez izateko.

Gomendatutako fluxua:

```text
Biltegia

(sekreturik gabe)

        ↓

Produkzio zerbitzaria

(ingurune-aldagaiak)

        ↓

Aplikazioa

(kargatutako konfigurazioa)
```

## Ingurune-aldagaiak definitzea

Aplikazio batek sistema-ingurunean emandako ingurune-aldagaiak jaso ditzake.

Adibidea:

```text
APP_ENV=production

APP_DEBUG=false

DB_HOST=db-interno

DB_DATABASE=txurdigest

DB_USERNAME=usuario_app

DB_PASSWORD=secreto
```

Aldagai hauek aplikazioa exekutatzen den ingurunetik ematen dira.

## Ingurune-aldagaiak PHP-n kargatzea

PHP-k ingurune-aldagaiak honela kontsulta ditzake:

```php
getenv()
```

Adibidea:

```php
$host = getenv('DB_HOST');

$usuario = getenv('DB_USERNAME');

$password = getenv('DB_PASSWORD');
```

Aplikazioak balioak erabiltzen ditu, baina ez ditu kredentzialak barnean edukitzen.

## `.env` bidez konfigurazioa

Garapenean fitxategi hau erabil daiteke:

```text
.env
```

Adibidea:

```text
DB_HOST=localhost

DB_DATABASE=txurdigest_dev

DB_USERNAME=root

DB_PASSWORD=
```

Fitxategi honek konfigurazio ezberdinak lantzea errazten du.

Hala ere:

```text
.env sekretuak dauzka

        ↓

babestu egin behar da
```

## `.env` fitxategiaren babesa

`.env` fitxategia ez da:

- biltegira igo behar;
- beharrezkoa ez den zerbitzarietara kopiatu behar;
- URL publiko baten bidez eskuragarri izan behar;
- kontrolik gabe partekatu behar.

Honela sartu behar da:

```text
.gitignore
```

Adibidea:

```text
.env
```

## `.env.example`

Konfigurazio beharrezkoa dokumentatzeko honela erabil daiteke:

```text
.env.example
```

Adibidea:

```text
APP_ENV=

APP_DEBUG=

DB_HOST=

DB_DATABASE=

DB_USERNAME=

DB_PASSWORD=
```

Fitxategi hau proiektuan parteka daiteke, balio errealik ez duelako.

Ohiko prozesua:

```text
.env.example

        ↓

kopiatu

        ↓

.env

        ↓

inguruneetako balioak sartu
```

## Laravel eta ingurune-aldagaiak

Laravel-ek normalean hau erabiltzen du:

```text
.env
```

konfigurazioa kargatzeko.

Adibidea:

```text
APP_ENV=production

APP_DEBUG=false

APP_KEY=valor-secreto
```

Produkcionean bereziki garrantzitsua da:

```text
APP_DEBUG=false
```

barne-informazioa ez erakusteko.

Konfigurazioa aldatzen denean cachea eguneratu beharra izan daiteke:

```bash
php artisan config:cache
```

## Ingurune-aldagaiak Linux zerbitzarian

Linux zerbitzari batean aplikazioa exekutatzen duen prozesuaren ingurune-aldagaiak defini daitezke.

Kontzeptu mailan:

```text
Sistema eragilea

        ↓

PHP/Laravel prozesua

        ↓

Aplikazioa
```

Aplikazioak ez du beharrezkoa balioak bere fitxategi barruan gorde.

## `.env` fitxategiaren baimenak

Badagoen arren, `.env` fitxategia baimen egokiekin babestu behar da.
