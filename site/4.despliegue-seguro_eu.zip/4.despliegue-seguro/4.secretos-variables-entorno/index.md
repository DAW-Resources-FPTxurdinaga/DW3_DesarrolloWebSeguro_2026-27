# Sekretuak eta ingurune-aldagaiak

Aplikazioek beste zerbitzu batzuekin konektatzeko konfigurazio-informazioa behar dute.

Adibide batzuk:

- datu-basearen kredentzialak;
- API giltzak;
- tokenak;
- zifraketa-giltzak;
- kanpoko zerbitzuen pasahitzak.

Datu hauek beharrezkoak dira aplikazioak funtzionatzeko, baina ez dute negozio-logikaren parte.

Horregatik konfigurazio kanpoko gisa kudeatu behar dira.

## Kodea eta sekretuak

Praktika ez-segurua da sekretuak zuzenean kodean sartzea.

Adibidea:

```php
$usuario = "admin";
$password = "clave123";
```

edo:

```javascript
const apiKey = "abc123";
```

Ikuspegi honek hainbat arazo sortzen ditu:

- sekretua kodearekin batera gordetzen da;
- biltegi batera ager daiteke;
- beste inguruneetara kopiatu daiteke;
- zailagoa da kredentzialak aldatzea.

Aplikazioak sekretua nola lortzen jakin behar du, baina ez du zuzenean eduki behar.

## Kodea eta konfigurazioa bereiztea

Gomendatutako eredua:

```text
Iturburu kodea

        +

Ingurunearen konfigurazioa

        ↓

Exekutatzen ari den aplikazioa
```

Kode berak konfigurazio desberdinak erabil ditzake:

```text
Garapena

Proba-datu-basea


Produkcioa

Datu-base erreal
```

Aplikazioa aldatzeko beharrik gabe.

## Ingurune-aldagaiak

Ingurune-aldagaiak prozesua abiaraztean informazioa emateko aukera ematen dute.

Adibidea:

```text
DB_HOST=servidor-interno
DB_DATABASE=txurdigest
DB_USERNAME=usuario_app
DB_PASSWORD=secreto
```

Aplikazioak balio hauek kontsultatzen ditu:

```php
$password = getenv('DB_PASSWORD');
```

Kodeak ez du balio errealik ezagutzen.

## Informazio sentikorren motak

Ez dira datu guztiak berdin garrantzitsuak.

Adibide batzuk:

### Kredentzialak

```text
Erabiltzailea
Pasahitza
Sarbide-tokenak
```

Zerbitzu baten aurrean autentifikatzeko aukera ematen dute.

### Kriptografia-giltzak

Adibidea:

```text
APP_KEY
SECRET_KEY
```

Honakoak bezalako eragiketetarako erabiltzen dira:

- zifraketa;
- datuen sinadura;
- tokenen sorrera.

### Kanpoko zerbitzuen giltzak

Adibidez:

```text
API_KEY
```

zerbitzu kanpokoekin komunikatzeko.

Guzti hauek sekretu gisa babestu behar dira.

## `.env` fitxategia

Inguru askok fitxategi hau erabiltzen dute:

```text
.env
```

konfigurazio lokala gordetzeko.

Adibidea:

```text
APP_ENV=production
APP_DEBUG=false

DB_HOST=db-interno
DB_PASSWORD=secreto
```

Fitxategi hau erosoa da garapenean, baina informazio sentikorra dauka.

Horregatik:

```text
.env

EZ da argitaratu behar
```

## Git biltegiak

Ohiko akats handienetako bat sekretuak ustekabean biltegira igotzea da.

Adibidea:

```bash
git add .
git commit
git push
```

`.env` barne hartzen bada, kredentzialak proiektuaren historiara gorde daitezke.

Prebentzio arrunta:

```text
.gitignore
```

Adibidea:

```text
.env
```

## Ez da nahikoa argitaratutako sekretua ezabatzea

Pasahitz bat Git-era ustekabean igotzen bada, fitxategia commit ondoren ezabatzeak ez du beti arazoa konpontzen.

Sekretua honakoetan egon daiteke:

- historia;
- babeskopiak;
- kloneak;
- kanpoko sistemak.

Ekintza zuzena hau da:

```text
Detektatu esposizioa

        ↓

Bertan behera utzi edo aldatu sekretua

        ↓

Kendu arrastoa hala dagokionean

        ↓

Eguneratu konfigurazioa
