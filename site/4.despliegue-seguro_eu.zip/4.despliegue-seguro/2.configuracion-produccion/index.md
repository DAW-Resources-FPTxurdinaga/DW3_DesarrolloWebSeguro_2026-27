# Produkzio-konfigurazioa

Aplikazio baten konfigurazioa exekutatzen den ingurunean moldatu behar da.

Kode bera garapenean, probetan eta produkzioan erabili daiteke, baina balio batzuk aldatu behar dira:

- exekuzio-modua;
- kredentzialak;
- bideak;
- erabilitako zerbitzuak;
- erakutsitako informazio-maila;
- arazketa-aukerak.

Konfigurazioa ez da iturburu-kodearekin nahastu behar.

## Kodea eta konfigurazioa bereizita

Aplikazio batek bereizketa argi mantendu beharko luke:

```text
Iturburu kodea
      +
Ingurunearen konfigurazioa
      ↓
Exekutatzen ari den aplikazioa
```

Kodeak aplikazioaren portaera definitzen du.

Konfigurazioak ingurune jakin batean nola exekutatzen den definitzen du.

Adibidea:

```text
Garapena

Datu-basea:
localhost

Produkcioa

Datu-basea:
barne-zerbitzaria
```

Aplikazioa bera da, baina konfigurazioa aldatzen da.

## Garapenaren eta produkzioaren konfigurazioa

Garapenean programazioa errazteko aukerak aktibatu daitezke:

```text
DEBUG = true
```

Honek honakoak erakutsi ditzake:

- errore osoak;
- exekuzio-trazak;
- framework-aren informazioa;
- barne xehetasunak.

Produkcionean aukera hauek desaktibatu behar dira.

Adibide kontzeptuala:

```text
Garapena

Errore xeheak
Arazketa aktibo
Informazio teknikoa ikusgai


Produkcioa

Errore kontrolatuak
Erregistro barnekoa
Erabiltzaileari informazio minimoa
```

## Arazketa-modua

Erroreen mezuak erabilgarriak dira garapenean.

Adibidez:

```text
Error SQL:
tabla usuarios no encontrada
archivo:
/var/www/app/modelo.php
línea 35
```

Informazio honek programatzaileari laguntzen dio.

Baina produkzioan honakoak agerian utzi ditzake:

- barne-egitura;
- zerbitzariaren bideak;
- taulen izenak;
- erabilitako osagaiak.

Aplikazioak mezu generiko bat erakutsi behar du:

```text
Ezin izan da eragiketa osatu.
```

eta barnean xehetasun teknikoa erregistratu.

## Ingurune-aldagaien bidez konfigurazioa

Ohiko praktika bat ingurune-aldagaiak erabiltzea da.

Adibidea:

```text
DB_HOST=servidor-bd
DB_NAME=txurdigest
DB_USER=usuario_app
DB_PASSWORD=secreto
```

Kodeak balio hauek kontsultatzen ditu:

```php
$dbHost = getenv('DB_HOST');
```

Aplikazioak ez du instalazio bakoitzaren balio konkretuak ezagutu behar.

## Konfigurazioaren bereizketaren abantailak

Bereizketa honek honakoak ahalbidetzen ditu:

### Ingurune ezberdinak erabili

Aplikazio bera honela exekuta daiteke:

```text
Garapena
    ↓
Datu-base lokala

Probak
    ↓
Proba-datu-basea

Produkcioa
    ↓
Datu-base erreal
```

kodea aldatzeko beharrik gabe.

### Informazio sentikorra babestea

Honako bezalako datuak:

- pasahitzak;
- API giltzak;
- tokenak;
- zerbitzuen kredentzialak;

ez dira proiektuko fitxategietan gorde behar, argitaratu daitezkeen tokietan amai litezkeelako.

### Hedapena erraztu

Zerbitzari berri bat konfiguratu ahal izango da beharrezko aldagaiekin aplikazioa aldatzeko beharrik gabe.

## Konfigurazio-fitxategiak

Zenbait framework-ek honelako fitxategiak erabiltzen dituzte:

```text
.env
```

konfigurazioa lokalea gordetzeko.

Adibidez:

```text
APP_ENV=production
APP_DEBUG=false

DB_HOST=localhost
DB_DATABASE=txurdigest
```

Fitxategi hauek behar bezala kudeatu behar dira.

Ez dira publikoko biltegietan sartu behar.

## `.env` fitxategia eta Git

Ohiko errore bat:

```text
.env
```

biltegira igotzea da.

Honek honakoak agerian utzi ditzake:

- pasahitzak;
- giltza pribatuak;
- tokenak;
- konexio-datuak.

Ohiko praktika hau da:

```text
.gitignore
```

eta adibide-fitxategi bat ematea:
