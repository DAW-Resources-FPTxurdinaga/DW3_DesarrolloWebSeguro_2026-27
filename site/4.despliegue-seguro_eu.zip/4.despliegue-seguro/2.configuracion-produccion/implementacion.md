# Produkzio-konfigurazioaren inplementazioa

Produkzio-konfigurazioa aplikazioa ingurune erreal batean funtzionatzeko baimendu behar du, kodea aldatzeko beharrik gabe.

Ideia nagusia hau da:

```text
Kode bera

        ↓

Konfigurazio ezberdinak

        ↓

Ingurune ezberdinak
```

Aplikazioak exekutatzeko behar dituen balioak ingurunetik jaso behar ditu.

## Ingurune-aldagaiak PHP-n

PHP-k ingurune-aldagaiak honela atzi ditzake:

```php
getenv()
```

Adibidez:

```php
$dbHost = getenv('DB_HOST');

$dbName = getenv('DB_DATABASE');

$dbUser = getenv('DB_USERNAME');

$dbPassword = getenv('DB_PASSWORD');
```

Aplikazioak balio hauek erabiltzen ditu, baina ez du non definituta dauden ezagutzen.

## Datu-basearen konexio-adibidea

Konexio ez-seguru batek honakoak izan ditzake:

```php
$pdo = new PDO(
    'mysql:host=localhost;dbname=txurdigest',
    'admin',
    'password123'
);
```

Arazoa hauxe da:

- kredentzialak kodean daudela;
- Git-en amaitu daitezkeela;
- ingurune guztiek balio berberak erabiliko dituztela;
- konfigurazioa aldatzeko aplikazioa aldatu beharra dagoela.

Alternatiba bat:

```php
$pdo = new PDO(
    getenv('DB_DSN'),
    getenv('DB_USERNAME'),
    getenv('DB_PASSWORD')
);
```

Orain konfigurazioa ingurunea da.

## `.env` fitxategia

Framework askok ingurune-aldagaien bidezko konfigurazio-fitxategiak erabiltzen dituzte.

Adibidea:

```text
APP_ENV=production
APP_DEBUG=false

DB_HOST=servidor-bd
DB_DATABASE=txurdigest
DB_USERNAME=usuario_app
DB_PASSWORD=secreto
```

`.env` fitxategia lan egiteko modua da, baina babestu egin behar da.

Ez du:

- argitaratu behar;
- biltegira bidali behar;
- beharrik gabe partekatu behar.

## `.env.example`

Ohiko praktika bat txantiloi bat mantentzea da:

```text
APP_ENV=
APP_DEBUG=

DB_HOST=
DB_DATABASE=
DB_USERNAME=
DB_PASSWORD=
```

Txantiloi honek aplikazioak behar dituen aldagaiak adierazten ditu, baina ez du informazio sentikorik.

Fluxua hau izango litzateke:

```text
.env.example

        ↓

kopiatu

        ↓

.env balio errealekin
```

## Git-ekin konfigurazioa

Fitxategi hau:

```text
.env
```

normalean honen barruan sartu behar da:

```text
.gitignore
```

Adibidea:

```text
.env
```

Horri esker Git-ek ez du biltegian sartuko.

Ondoren honela egiaztatu daiteke:

```bash
git status
```

ez dagoela fitxategi zain gisa.

## Laravel produkzioan konfigurazioa

Laravel-ek ingurune-aldagaiak honela erabiltzen ditu:

```text
.env
```

Zenbait balio garrantzitsu:

```text
APP_ENV=production

APP_DEBUG=false

APP_KEY=clave-secreta
```

Bereziki garrantzitsua:

```text
APP_DEBUG=false
```

Produkcionean ez dira salbuespen osoak erakutsi behar erabiltzaileari.

Aplikazio batek honakoak agerian utzi ditzake:

- barne-bideak;
- kontsultak;
- framework-aren egitura;
- zerbitzariaren informazioa.

## Laravel-en konfigurazio-cachea

Laravel-ek konpilatutako konfigurazioa gorde dezake errendimendua hobetzeko.

Ingurune-aldagaiak aldatzen direnean cachea eguneratu beharra izan daiteke:

```bash
php artisan config:cache
```

Aplikazioak erabiltzen duen konfigurazioa ingurune errealari dagokion izan behar du.

## Produkzioaren dependentzioak

Produkcionean instalatutako dependentzioak soilik beharrezkoak izan behar dira.

Adibidez, PHP-n Composer-ekin:

```bash
composer install --no-dev --optimize-autoloader
```

Aukera hau:

```text
--no-dev
```

garapen-fasean bakarrik erabilitako dependentzioak ez instalatzeko balio du.
