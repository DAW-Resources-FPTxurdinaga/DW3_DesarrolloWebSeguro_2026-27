# HTTPS eta ziurtagiriak

HTTPS da nabigatzailearen eta zerbitzariaren arteko komunikazioa zifratu eta autentikatu ahalbidetzen duen mekanismoa.

Bloke 1-ean HTTPS-ren funtzionamendu kontzeptuala eta ziurtagiri-katearen konfiantza-ikurrea aztertu zen.

Bloke honetan hedapenean aplikatzeko zentratuko gara:

- HTTPS aktibatzea produkzioan;
- zerbitzaria behar bezala konfiguratu;
- ziurtagiri baliagarriak erabiltzea;
- seguru ez den trafikoa birbideratzea;
- aplikazioa HTTPS gainean behar bezala funtzionatzen duela egiaztatzea.

## HTTP-tik HTTPS-era

HTTP bidez argitaratutako aplikazio batek komunikazioak ez ditu kriptografikoki babesturik transmititzen.

```text
Bezeroa
   |
   | HTTP
   |
Zerbitzaria
```

Honek komunikazioan informazioa behatu edo aldatzea ahalbidetu dezake.

HTTPS-ek babesa geruza bat gehitzen du:

```text
Bezeroa
   |
   | HTTPS
   |
Zerbitzaria
```

Komunikazioa TLS bidez babestu egiten da.

## HTTPS produkzioan

Garapenean ohikoa da erabiltzea:

```text
http://localhost
```

edo probako ziurtagiriak.

Hala ere, erabiltzaile errealek atzitu dezaketen aplikazio batek hau erabili behar du:

```text
https://adibide-domeinua.com
```

Hedapenak honakoak izan behar ditu:

- ziurtagiri baliagarria;
- web-zerbitzariaren konfigurazioa;
- ziurtagiriaren berritzea;
- HTTP trafikoaren birbideraketa.

## Ziurtagiri digitalak

Ziurtagiri batek zerbitzari bati identitate digital bat lotzen dio.

Kontzeptu mailan:

```text
Zerbitzaria
    ↓
Ziurtagiri digitala
    ↓
Ziurtagiri Autoritatea
    ↓
Nabigatzailearen konfiantza
```

Nabigatzaileak egiaztatzen du:

- ziurtagiria baliagarria dela;
- domeinuari dagokion;
- autoritate ezagun batek sinatuta dagoela;
- ez dela iraungita.

## Ziurtagiri bat lortzea

Inguru erreal batean ziurtagiriak normalean Ziurtagiri Autoritate baten bidez lortzen dira.

Ohiko aukera bat honakoak emandako ziurtagiriak erabiltzea da:

```text
Let's Encrypt
```

Ziurtagiri hauek nabigatzaile modernoek aitortzen dituzte eta berritzea automatizatzeko aukera ematen dute.

Prozesu orokorra:

```text
Ziurtagiriaren eskaera

        ↓

Domeinuaren balidazioa

        ↓

Instalazioa zerbitzarian

        ↓

HTTPS konfigurazioa

        ↓

Aldian-aldiko berritzea
```

## Web-zerbitzariaren konfigurazioa

Zerbitzariak jakin behar du:

- ziurtagiri publikoa;
- lotutako giltza pribatua;
- HTTPS gunearen konfigurazioa.

Giltza pribatua babestuta mantendu behar da.

Inoiz ez du:

- Git-era igo behar;
- hirugarren bati bidali behar;
- aplikazioaren kodean sartu behar.

## HTTP-tik HTTPS-era birbideratzea

Ohiko praktika bat bi bertsio eskuragarri ez izatea da:

```text
http://adibidea.com

https://adibidea.com
```

Gomendatutako konfigurazioa:

```text
HTTP
  ↓
betiko birbideraketa
  ↓
HTTPS
```

Horrela erabiltzaileak komunikazio babestua erabiltzea behartzen da.

## Adibide kontzeptuala

Hasierako eskaera:

```text
Erabiltzailea

http://txurdigest.adibidea
```

Zerbitzaria:

```text
301 Redirect

https://txurdigest.adibidea
```

Eskaera berria:

```text
Erabiltzailea

https://txurdigest.adibidea
```

Komunikazioa HTTPS erabiliz jarraitzen du.

## Ziurtagiriak berritzea

Ziurtagiriak iraungitze-data dute.

Horregatik, hedapenak honakoak izan behar ditu:

- aldian-aldiko berrikuspena;
- berritze automatikoa ahal denean;
- ondorengo egiaztapena.

Iraungitako ziurtagiriak nabigatzaileetan segurtasun-abisuei eragiten die.

## HTTPS eta cookie-ak

Aplikazio batek saioak cookie bidez erabiltzen baditu, HTTPS-ek segurtasun-atributu gehigarriak erabiltzeko aukera ematen du.

Adibidez:

```text
Secure
HttpOnly
SameSite
```

```text
Secure
```

atributuak adierazten du cookie-a HTTPS bidez soilik bidali behar dela.

Adibide kontzeptuala:
