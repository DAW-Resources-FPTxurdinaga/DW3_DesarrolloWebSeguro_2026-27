# HTTPS eta ziurtagiriak ezartzea

HTTPS aktibatzea produkzioan esan nahi du zerbitzaria behar bezala konfiguratu, ziurtagiri baliagarria instalatu eta aplikazio osoak komunikazio seguruak erabiltzen dituela egiaztatzea.

Helburua ez da soilik nabigatzaileko giltza agertzea, baizik ere:

- domeinua behar bezala identifikatuta dagoela;
- komunikazioa zifratuta dagoela;
- cookie sentikorrak babestuta bidaiatu direla;
- HTTP bidez seguru ez diren sarbiderik ez dagoela.

## Ziurtagiri eta giltza pribatua

TLS ziurtagiri batek zerbitzaria identifikatzen duen informazio publikoa dauka.

Lotutako giltza pribatua zerbitzariaren identitatea frogatzeko aukera ematen du konexioan.

Erlazioa:

```text
Ziurtagiri publikoa
        +
Giltza pribatua
        ↓
HTTPS komunikazio segurua
```

Giltza pribatua bereziki babestu behar da.

Inoiz ez du:

- biltegian sartu behar;
- kodean kopiatu behar;
- beharrik gabe partekatu behar.

## Ziurtagiria instalatzea

Hedapenaren prozesu arrunta hau da:

```text
Ziurtagiria lortu

        ↓

Zerbitzari web-ean instalatu

        ↓

HTTPS gunea konfiguratu

        ↓

Zerbitzaria berrabiarazi edo birkargatu

        ↓

Funtzionamendua egiaztatu
```

Konfigurazio zehatza erabilitako zerbitzariaren arabera aldatzen da.

## Adibide kontzeptuala Apache-rekin

Apache zerbitzari batek HTTPS gune bat konfiguratu behar du.

Kontzeptu mailan:

```text
<VirtualHost *:443>

    ServerName txurdigest.adibidea

    SSLEngine on

    SSLCertificateFile certificado.crt

    SSLCertificateKeyFile clave-privada.key

</VirtualHost>
```

Izen eta bide zehatzak instalazioaren arabera aldatzen dira.

Garrantzitsua ulertzea da:

- ziurtagiria publikoa dela;
- giltza pribatua babestuta egon behar dela;
- zerbitzariak biekotza erabiltzen duela HTTPS ezartzeko.

## HTTP-tik HTTPS-era birbideratzea

HTTPS aktibatu ondoren ez litzateke HTTP bidez sarbide ez-seguruak mantendu behar.

Ohiko konfigurazioa:

```text
80 portua
    ↓
301 birbideratzea
    ↓
443 portua
```

Erabiltzailea beti HTTPS erabiliz amaituko du.

Adibidea:

```text
http://txurdigest.adibidea

        ↓

https://txurdigest.adibidea
```

## Edukiondo mistoa saihestea

HTTPS aplikazio batek babesa galtzen du HTTP bidez baliabideak kargatzen baditu.

Adibide okerra:

```html
<script src="http://adibidea.com/app.js"></script>
```

Nahiz eta orri nagusia HTTPS erabiliz izan, baliabide hori baberik gabe eskatzen da.

Erabili behar da:

```html
<script src="https://adibidea.com/app.js"></script>
```

edo bide erlatiboak:

```html
<script src="/app.js"></script>
```

## Nabigatzailearen bidez egiaztatzea

Nabigatzailearen tresnek honakoak egiaztatu ditzakete:

- erabilitako ziurtagiria;
- HTTPS eskaerak;
- kargatutako baliabideak;
- bidalitako cookie-ak.

Adibidez, DevTools-en:

```text
Network

        ↓

HTTPS protokoloa egiaztatu
```

Era berean berrikusi daiteke:

```text
Application

        ↓

Cookies

        ↓

Secure atributua
```

## Saio-cookie-ak eta HTTPS

Saioak dituzten aplikazio batek bere cookie-ak babestu behar ditu.

Adibidea:

```http
Set-Cookie:
session_id=abc123;
Secure;
HttpOnly;
SameSite=Lax
```

```text
Secure
```

atributuak cookie-a HTTP konexio bidez bidali ez dadin eragozten du.

HTTPS eta cookie-en konfigurazio zuzena elkarrekin lan egiten dute.

## Berritze automatikoa

Ziurtagiriak iraupen mugatua dute.

Hedapen profesional batek honakoa kontuan izan behar du:

```text
Ziurtagiri baliagarria
        ↓
Iraungitze data
        ↓
Berritzea
        ↓
Egiaztapen berria
```

Berritze automatikoa ziurtagiri iraungituengatik etenak murrizten du.

## HTTPS AWS-n

AWS-n ohiko hedapenean hainbat aukera egon daitezke:

```text
Erabiltzailea
