# Datu-basea hedapen seguruan

Datu-basea aplikazio webaren osagai garrantzitsuenetariko bat da.

Informazio kritikoa eduki dezake:

- erabiltzaileak;
- pasahitz zifratuta;
- datu pertsonalak;
- negozio-informazioa;
- jardueren erregistroak.

Horregatik, hedapenean bere konfigurazioak babes-neurri espezifikoak aplikatu behar ditu.

## Datu-basea ez da zuzenean erakutsi behar

Arkitektura segurua osagaiak bereizten ditu:

```text
Erabiltzailea

    ↓ HTTPS

Web zerbitzaria

    ↓

Aplikazioa

    ↓

Datu-basea
```

Erabiltzaileak ez luke datu-baseari zuzenean konektatu behar.

Arkitektura okerra:

```text
Internet

    ↓

Datu-basea
```

Aplikazioak kontrolatu behar du zein eragiketa egin daitezkeen.

## Aplikazioa eta datu-basea bereiztea

Datu-basea zerbitzu barne gisa kontuan hartu behar da.

Adibidea:

```text
Web zerbitzaria

IP publikoa


Datu-basea

IP pribatua
```

Aplikazioak datu-basearekin komunikatu ahal du, baina kanpoko erabiltzaileek ez lukete sarbide zuzena izan behar.

## Aplikazioaren erabiltzaile espezifikoa

Ohiko akatsa pribilegio gehiegi dituzten kontuak erabiltzea da.

Adibide okerra:

```text
Aplikazioa

    ↓

Datu-basearen administratzaile-erabiltzailea
```

Aplikazioak arazo seguru bat badu, pribilegio altuak dituen erabiltzaile batek ondorio larriagoak izan ditzake.

Modelo gomendatua:

```text
Aplikazioa

    ↓

Erabiltzaile espezifikoa

    ↓

Beharrezko baimenak
```

## Gutxieneko pribilegioaren printzipioa datu-basean

Aplikazioak erabiltzen duen kontuak behar dituen baimenak soilik izan behar ditu.

Adibidez:

```text
Baimendu:

SELECT
INSERT
UPDATE

Ez baimendu:

erabiltzaileak sortzea
datu-baseak ezabatzea
zerbitzariaren konfigurazioa aldatzea
```

Aplikazioak ez luke kontu administratzaile bat erabili behar.

## Datu-basearen kredentzialak

Konexio-kredentzialak aplikazioaren sekretuen parte dira.

Inoiz ez lukete agertu:

```php
$usuario = "root";
$password = "123456";
```

Kanpo konfigurazioaren bidez eman behar dira:

```text
DB_HOST=db-interno

DB_DATABASE=txurdigest

DB_USERNAME=usuario_app

DB_PASSWORD=secreto
```

Aplikazioak inguruneetako balioak erabiltzen ditu.

## Konexioa aplikazioaren bidez

Konexioa konfigurazioak emandako datuekin erabili behar da.

Adibidea:

```php
$pdo = new PDO(
    getenv('DB_DSN'),
    getenv('DB_USERNAME'),
    getenv('DB_PASSWORD')
);
```

Aplikazioak ez du jakin behar nola gordetzen diren balio horiek.

## Komunikazioen zifratzea

Aplikazioa eta datu-basea bananduta badaude, bien arteko komunikazioa babestu behar da.

Adibideak:

```text
Web zerbitzaria

       ↓ konexio segurua

Datu-basea
```

Beharrezkoak direnak:

- arkitektura;
- erabilitako sarea;
- datuen sentikortasuna;
- ingurunearen eskakizunak.

## Babeskopiak

Datu-base segurua babeskopia-estrategia bat behar du.

Honakoak definitu behar dira:

- maiztasuna;
- kokapena;
- babesa;
- mantentze-denbora;
- berreskuratze-prozedura.

Babeskopia informazio sentikorra dauka.

Horregatik:

```text
Backup

ere datu sentikorra da eta babestu behar da
```

## Pasahitzak testu lauan ez gordetzea

Datu-baseak ez du pasahitzik zuzenean gorde behar.

Gaizki:

```text
erabiltzailea

password123
```

Ondo:

```text
erabiltzailea

hash
```

PHP-n:

```php
password_hash()
```

eta:

```php
password_verify()
```

pasahitzak behar bezala kudeatzeko aukera ematen dute.

## Erregistroak eta datu sentikorrak

Aplikazioaren erregistroek ez lukete honakoak gorde behar:

- pasahitzak;
- token osoak;
- API giltzak;
- beharrezkoa ez den datu osoak.

Adibide okerra:

```text
Erabiltzailea login:

ana

Pasahitza:

secreto123
```

Erregistroak ere datu sentikorrak direla kontuan hartu behar da.

## Administrazio-tresnak

Garapenean honakoak erabili daitezke:

- phpMyAdmin;
- bezero grafikoak;
- web-panelak.

Produkcionean berrikusi behar dira.

Aukerak:

- ezabatu;
- sarbidea mugatu;
- autentikazio gehigarri batekin babestu;
- sarearen arabera mugatu.

## TxurdiGest-en adibidea

Konfigurazioa:

```text
Aplikazio zerbitzaria

        ↓

Erabiltzailea:

txurdigest_app

        ↓

Datu-basea:

txurdigest
```

Baimenak:

```text
Taula beharrezkoak lantzeko gai da

Ez du zerbitzari osoa administratzeko gaitasunik
```

Sarea:

```text
Internet

    ↓

Web zerbitzaria

    ↓

Datu-base pribatua
```

## Checklist-a

```text
[ ] Aplikazioak ez du administratzaile-erabiltzailerik erabiltzen

[ ] Kredentzialak kodearen kanpo daude

[ ] Datu-baseak ez du Internetetik konexiorik onartzen

[ ] Erabiltzaileak baimen minimoak ditu

[ ] Migratzeak kontrolatuak daude

[ ] Babeskopiak babestuta daude

[ ] Berreskuratzea probatu da

[ ] Administrazio-tresnak babestuta daude

[ ] Erregistroek ez dute sekreturik daukaten
```

## Giltzarri ideia

> Datu-basearen segurtasuna ez da soilik sarbidea programatzeko moduan, baita exekutatzen den ingurunean nola konfiguratzen den ere.
