# Datu-basearen inplementazio segurua

Produkciorako datu-base baten inplementazioak ziurtatu behar du aplikazio baimendua baino ez duela atzitu ahal izatea.

Konfigurazio segurua honakoak konbinatzen ditu:

```text
Kokapen egokia

        +

Kredentzialak babestuta

        +

Baimen minimoak

        +

Babeskopiak
```

## Aplikazioarentzat erabiltzaile espezifikoa sortzea

Aplikazioa ez luke administratzaile-erabiltzaileak erabiliz konektatu behar.

Adibide okerra:

```text
Erabiltzailea:

root

Baimenak:

dena
```

Aplikazioak segurtasun-arazo bat badu, pribilegio altuak dituzten erabiltzaile batek eragina handitzen du.

Modelo gomendatua:

```text
Datu-basea

        ↓

Aplikazio-erabiltzailea

        ↓

Beharrezko baimenak
```

## Baimenen adibidea

Aplikazio tipiko batek honakoak behar ditzake:

```text
SELECT

INSERT

UPDATE

DELETE
```

Baina normalean ez du behar:

```text
CREATE USER

DROP DATABASE

Zerbitzariaren konfigurazioa aldatzea
```

Baimenak eragiketa errealetara doituko dira.

## Konexioa konfiguraziotik sortzea

Aplikazioak konexio-datuak ingurune-aldagaien bidez lortu behar ditu.

Adibidea:

```text
DB_HOST=db-interno

DB_DATABASE=txurdigest

DB_USERNAME=txurdigest_app

DB_PASSWORD=secreto
```

Aplikazioak balio hauek erabiltzen ditu:

```php
$conexion = new PDO(
    getenv('DB_DSN'),
    getenv('DB_USERNAME'),
    getenv('DB_PASSWORD')
);
```

Iturburu-kodeak ez du kredentzialik eduki behar.

## Ez erabili administrazio-konexioak

Garapenean ohiko praktika bat hau da:

```text
root
```

erabiltzea, probak errazteko.

Produkciora baino lehen erabiltzaile espezifiko batekin ordezkatu behar da.

Adibidea:

Garapena:

```text
root
```

Produkcioa:

```text
txurdigest_app
```

baimen mugatuekin.

## Sareko sarbidea mugatzea

Datu-baseak soilik beharrezko zerbitzuekiko konexioak onartu beharko lituzke.

Arkitektura:

```text
Web zerbitzaria

IP baimendua

        ↓

Datu-basea
```

Ez:

```text
Internet

        ↓

Datu-basea
```

AWS-n kontrol hau sare-arauen eta Security Groups-en bidez egin daiteke.

## Security Groups-ekin adibidea

Web zerbitzaria:

```text
Sarrera:

443 HTTPS
22 SSH mugatua
```

Datu-basea:

```text
Sarrera:

3306

jatorria:
aplikazio-zerbitzaria
```

Datu-baseak ez du edozein jatorritatik onartzen konexioak.

## Ingurune-aldagaiak produkzioan

Zerbitzarian:

```text
DB_HOST=db-pribatua

DB_DATABASE=txurdigest

DB_USERNAME=txurdigest_app

DB_PASSWORD=balio-erreal
```

Biltegian:

```text
Ez dago kredentzialik
```

Hedapenak beharrezkoa den konfigurazioa ematen du.

## Datu-basearen migrazioak

Aplikazioek sarritan egitura eguneratu behar dute:

```text
Bertsio berria

        ↓

Migrazioa

        ↓

Datu-basea eguneratua
```

Adibideak:

- taulak sortu;
- zutabeak gehitu;
- indizeak aldatu.

Eragiketa hauek modu kontrolatuan egin behar dira.

## Migrazio okerrak

Migrazio gaizki diseinatua honakoak eragin ditzake:

- datuak galtzea;
- taulak blokeatzea;
- informazio okerra aldatzea.

Praktika onak:

- probak egin inguruneetan lehenengo;
- babeskopiak egin;
- aldaketa suntsitzaileak berrikusi;
- berreskuratze-prozedura mantendu.

## Babeskopiak

Babeskopia oinarrizko bat:

```bash
mysqldump
```

fitxategi bat sor dezake guztiekin datuekin.

Fitxategi hori babestu behar da.

Adibidea:

```text
backup.sql
```

honakoak eduki ditzake:

- erabiltzaileak;
- datu pertsonalak;
- negozio-informazioa.

Ez luke publikoki eskuragarri egon behar.

## Babeskopietatik berreskuratzea

Babeskopia erabilgarria da berreskuratzea egin badaiteke.

Berrikusi behar da:

```text
Babeskopia sortu

        ↓

Babeskopia berreskuratu

        ↓

Aplikazioa egiaztatu
```

Probatu gabe dagoen backup-ek ez du berreskuratzea bermatzen.

## Pasahitzak gordetzea

Erabiltzaileen pasahitzak ez dira zuzenean gorde behar.

Gaizki:

```text
erabiltzailea

contraseña123
```

Ondo:

```text
erabiltzailea

hash
```

PHP-n:

```php
password_hash()
```

eta:

```php
password_verify()
```

pasahitzak behar bezala kudeatzeko aukera ematen dute.

## Erregistroak eta datu sentikorrak

Aplikazioaren erregistroek ez lukete honakoak gorde behar:

- pasahitzak;
- tokenak;
- datu osoak beharrezkoak ez direnak.

Adibide okerra:

```text
Erabiltzailea login:

ana

Pasahitza:

secreto123
```

Erregistroak ere datu sentikorrak direla kontuan hartu behar da.

## Administrazio-tresnak

Garapenean honakoak erabili daitezke:

- phpMyAdmin;
- bezero grafikoak;
- web-panelak.

Produkcionean berrikusi behar dira.

Aukerak:

- ezabatu;
- sarbidea mugatu;
- autentikazio gehigarri batekin babestu;
- sarearen arabera mugatu.

## TxurdiGest-en adibidea

Konfigurazioa:

```text
Aplikazio zerbitzaria

        ↓

Erabiltzailea:

txurdigest_app

        ↓

Datu-basea:

txurdigest
```

Baimenak:

```text
Taula beharrezkoak lantzeko gai da

Ez du zerbitzari osoa administratzeko gaitasunik
```

Sarea:

```text
Internet

    ↓

Web zerbitzaria

    ↓

Datu-base pribatua
```

## Checklist-a

```text
[ ] Aplikazioak ez du administratzaile-erabiltzailerik erabiltzen

[ ] Kredentzialak kodearen kanpo daude

[ ] Datu-baseak ez du Internetetik konexiorik onartzen

[ ] Erabiltzaileak baimen minimoak ditu

[ ] Migratzeak kontrolatuak daude

[ ] Babeskopiak babestuta daude

[ ] Berreskuratzea probatu da

[ ] Administrazio-tresnak babestuta daude

[ ] Erregistroek ez dute sekreturik daukaten
```

## Giltzarri ideia

> Datu-basearen segurtasuna ez da soilik sarbidea programatzeko moduan, baita exekutatzen den ingurunean nola konfiguratzen den ere.
