# Log-ak eta erroreak produkzioan

Aplikazio segurua ez da bakarrik erroreak saihesten, baizik gertatzen direnean behar bezala kudeatzen ere.

Garapenean erroreak arazoak aurkitzeko laguntzen dute.

Produkcionean kudeaketa aldatu behar da:

```text
Garapena

errore informazioa erakutsi arazteko


Produkcioa

informazioa babestu + beharrezkoa dena erregistratu
```

Helburua aplikazioa modu kontrolatuan huts egitea da.

## Erabiltzailearen ikuspegia eta barneko erroreak

Arazo bat gertatzen denean bi beharrizan desberdin daude:

### Erabiltzailea

Argi informazio bat jasotzea behar du:

```text
Ezin izan da eragiketa osatu.
```

### Talde teknikoa

Ikerketa egiteko informazio nahikoa behar du:

```text
Data

Eragindako erabiltzailea

Egindako eragiketa

Errore teknikoa
```

Bi beharrizan hauek ez dira nahastu behar.

## Barne-informazioa ez erakustea

Erantzun ez-seguru batek honakoak erakutsi ditzake:

```text
Errore SQL osoa

Zerbitzariaren bidea

Framework-aren bertsioa

Barneko fitxategia

Kode-lerroa
```

Adibidea:

```text
Fatal error:
PDOException in /var/www/app/database.php line 45
```

Informazio honek erasotzaileari aplikazioari buruzko xehetasunak ezagutaraz ditzake.

Produkcionean mezu kontrolatu batez ordezkatu behar da.

## Erroreak barnean erregistratzea

Nahiz eta erabiltzaileak errore osoa ez ikusi, aplikazioak erregistratu behar du.

Adibidea:

```text
Erabiltzailea:

Ezin izan da erregistroa gorde.


Erregistro barnekoa:

2026-08-08
Errore konekzio BD
affect user
eragiketa-identifikatzailea
```

Erregistroak honakoak ahalbidetzen ditu:

- arazoak diagnostikatzea;
- incidentziak ikertzea;
- errepikatzen diren hutsegiteak detektatzea.

## Erregistroetan ez agertu behar den informazioa

Erregistroek ere arrisku bihur daitezke informazio gehiegi gordetzen badute.

Ez lukete gorde behar:

```text
Pasahitzak

Token osoak

API giltzak

Beharrezkoa ez den datu pertsonala

Informazio sentikorra
```

Adibide okerra:

```text
Erabiltzailea:
ana

Pasahitza:
secreto123
```

Erregistroak beharrezko informazioa soilik eduki behar du.

## Xehetasun-maila ingurunearen arabera

Aplikazio batek erregistro-maila ezberdinak erabili ditzake.

Garapena:

```text
Informazio gehiago

Xehetasun tekniko gehiago
```

Produkcioa:

```text
Informazio erabilgarria

Datu sentikorrik gabe
```

Konfigurazioa ingurunera egokitu behar da.

## PHP salbuespenak

PHP-k erroreak salbuespenen bidez kudeatzeko aukera ematen du.

Adibidea:

```php
try {

    guardarDatos();

} catch (Exception $e) {

    error_log(
        $e->getMessage()
    );

    mostrarErrorUsuario();
}
```

Aplikazioak problema erregistratzen du, baina ez ditu barne-xehetasunak erakusten.

## Laravel-en erroreak

Laravel-ek honakoak bezalako mekanismo propioak ditu:

- salbuespenen kudeaketa;
- log-ak sortzea;
- ingurune-konfigurazioa.

Elementu garrantzitsua:

```text
APP_DEBUG=false
```

produkcionean.

Konfigurazio honekin erabiltzaileari erroreen informazio xehea ez da erakusten.

## Zerbitzariaren log-ak

Aplikazioaren log-en gainera zerbitzariaren erregistroak egon daitezke:

- HTTP sarbideak;
- web-zerbitzariaren erroreak;
- sistemaren gertaerak.

Erregistro hauek honakoak aztertzeko laguntzen dute:

- jasotako eskaerak;
- errepikaturiko erroreak;
- konfigurazio-arazoak.

## Log fitxategien babesa

Log-ek informazio sentikorra eduki dezakete.

Horregatik:

```text
Logs

        ↓
```
