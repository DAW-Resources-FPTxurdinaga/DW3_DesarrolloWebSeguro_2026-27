# Log-ak eta erroreak produkzioan ezartzea

Erroreen kudeaketa hedapenaren konfigurazioaren parte izan behar du.

Aplikazio batek produkzioan bi helburu lortu behar ditu:

```text
Erabiltzaileari informatu informazio sentikorik erakutsi gabe

        +

Talde teknikoari behar adina informazio erregistratu
```

## Produkzio-ingurunean konfigurazioa ezartzea

Lehen urratsa ingurune-konfigurazioa berrikustea da.

PHP eta Laravel aplikazioetan erroreak zuzenean erakustea saihestu behar da.

Adibide kontzeptuala:

```text
Garapena

APP_DEBUG=true


Produkcioa

APP_DEBUG=false
```

Aplikazioak erroreak oraindik erregistratzen ditu, baina ez ditu erabiltzaileari erakusten.

## PHP konfigurazioa

PHP-k erroreen bistaratzearekin lotutako aukerak ditu.

Garapenean:

```ini
display_errors = On
```

programazioa errazten du.

Produkcionean:

```ini
display_errors = Off
```

barne-informazioa ez agerian uzten du.

Erroreak kontrolatutako erregistroetara bidali behar dira.

## Erroreen erregistroa

Erregistro batek honako galderak erantzuteko aukera eman behar du:

```text
Zer gertatu da?

Noiz gertatu da?

Zer eragiketa eragin zuen?

Zer erabiltzaile zen inplikatuta?

Non gertatu da?
```

Adibide kontzeptuala:

```text
Data:
08/08/2026 10:30

Eragiketa:
Erreserba sortu

Erabiltzailea:
154

Errorea:
BD konexio huts egin du
```

Erregistroak informazio erabilgarria dauka, baina ez sekreturik.

## PHP salbuespenak erregistratzea

Oinarrizko kudeaketa hau:

```php
try {

    realizarOperacion();

} catch (Exception $e) {

    error_log(
        $e->getMessage()
    );

    mostrarMensajeError();
}
```

Erabiltzaileari erantzun kontrolatua ematen zaio.

Xehetasuna erregistratuta geratzen da.

## Ez erregistratu informazio sentikorra

Hau saihestu behar da:

```text
Pasahitzak

Tokenak

API giltzak

Beharrezkoak ez diren datu osoak

Informazio bankaria
```

Adibide okerra:

```text
Erabiltzailea:
juan

Pasahitza:
123456
```

Adibide egokia:

```text
Erabiltzailea:
juan

Errorea:
autentikazio-errorea
```

## Laravel-en log-ak

Laravel-ek log-sistema propioa eskaintzen du.

Konfigurazioa honako bidez egiten da:

```text
config/logging.php
```

eta ingurune-aldagaiekin.

Adibidea:

```text
LOG_CHANNEL=stack

LOG_LEVEL=error
```

Erregistro-maila ingurunera egokitu behar da.

## Log-mailak

Erregistro-sistemek maila ezberdinak bereizten dituzte:

```text
debug

info

warning

error

critical
```

Produkcionean normalean informazio arazketa gehiegi saihestu nahi da.

Adibidea:

```text
Garapena:

debug


Produkcioa:

error
```

Konfigurazioa proiektuaren beharren arabera aldatuko da.

## Log-en kokapena

Erregistroak kokapen babestutan gorde behar dira.

Adibidea:

```text
storage/logs/
```

Ez lukete direktorio publikoa izan behar:

```text
public/
```
